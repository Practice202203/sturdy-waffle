var catalog__subcatalog_link = document.querySelector('.catalog__subcatalog-link_lvl');
var subcatalog_resist = document.querySelector('.subcatalog_resist');

catalog__subcatalog_link.addEventListener('mouseover', function () {

    subcatalog_resist.classList.add("subcatalog_resist_focus");

});
